<?php
include_once '../../../../vendor/autoload.php';

include_once '../../../../config/db.php';
include_once '../../../../models/faculty.php';
include_once '../../../../models/dept.php';
include_once '../../../../models/programme.php';
include_once '../../../../models/session.php';
// generate json web token
include_once '../../../../config/core.php';




$db = new Db();

$conn = $db->getConnection();

$f = new Faculty($conn);
$d = new Dept($conn);
$p = new Programme($conn);
$s = new Session($conn);

$f->allActive();
$d->allActive();
$p->allActive();
$s->check(24);

use GuzzleHttp\Psr7;
use GuzzleHttp\Exception\ClientException;

try {
    $response = $client->request('GET', 'application/all/complete/', [
        'query' => ['session' => htmlspecialchars(strip_tags($_GET['session']))]
    ]);
} catch (ClientException $e) {
    // var_dump($e->getRequest());
}
//var_dump($response);
$response =   json_decode($response->getBody(), true);
//var_dump($response);
$payload = $response['payload'];

function getName($obj, $id)
{



    $v = array_filter($obj, function ($var) use ($id) {
        return ($var['id'] == $id);
    });

    foreach ($v as $key) {

        if (isset($key['name'])) {
            return $key['name'];
            break;
        } else if (isset($key['programme'])) {
            return $key['programme'];
            break;
        }
    }

    return null;
}





?>

<html>

<head>
</head>

<body>
    <div class=' w-100  p-1'>
        <div class=' '>

              
            <table>
                <tr>
                    <td colspan=9>
                    FEDERAL UNIVERSITY OF LAFIA
                    </td>
                </tr>
                <tr>
                    <td colspan=9>
                    POST GRADUATE SCHOOL
                    </td>
                </tr>
                <tr>
                    <td colspan=9>
                    <?= $s->name ?>  APPLICATION
                    </td>
                </tr>
            </table>
           
        
        </div>
        <div class=' w-100'>


<table class=''>
    <?php

    foreach ($payload as $f_id => $d_id) {
        $temp = $f->all;
        try {
            $fac = getName($temp, $f_id);
        } catch (Exception $e) {
            echo $e->getMessage();
        }
        if ($fac != null) {
            $fac =  strtoupper($fac); ?>

            <thead>
                <tr>
                    <th colspan=9 > FACULTY OF <?= $fac  ?></th>
                </tr>
            </thead>
            <?php

            foreach ($payload[$f_id] as $d_id => $d_id) {
                $temp = $d->all;
                $dt = getName($temp, $d_id);
                if ($dt != null) {
                    $dt =  strtoupper($dt);
            ?>
                    <thead>

                        <tr>
                            <th  colspan=9 > DEPARTMENT OF <?= $dt ?> </th>

                        </tr>
                    </thead>
                    <?php
                    foreach ($payload[$f_id][$d_id] as  $p_id => $appd) {
                        $temp = $p->all;
                        $pt = getName($temp, $p_id);
                        if ($pt != null) {
                            $pt =  strtoupper($pt);
                    ?>
                            <thead>

                                <tr>
                                    <th colspan='9' scope='col'> PROGRAMME : <?= $pt ?> </th>

                                </tr>
                            </thead>
                            <thead>
                                <tr>
                                    <th scope='col'>#</th>
                                    <th scope='col'>Application ID</th>
                                    <th scope='col'>Name</th>

                                    <th scope='col'>Department</th>
                                    <th scope='col'>Programme</th>
                                    <th scope='col'>Degree Result(s)


                                    </th>
                                 
                                    <th scope='col'>Referee (s)</th>
                                    <th scope='col'>Remark</th>
                                </tr>
                            </thead>

                            <tbody>
                                <?php
                                $i = 1;
                                foreach ($payload[$f_id][$d_id][$p_id]  as   $appd) {
                                ?>
                                <tr>
                                    <td scope='row'><?= $i++  ?></td>
                                    <td><?= $appd['appd_id']  ?></td>
                                    <td><?= ucfirst($appd['surname']) . ' ' . ucfirst($appd['firstname']) . '  ' . ucfirst($appd['othername']) ?></td>

                                    <td><?= $dt  ?></td>
                                    <td><?= $pt ?></td>

                                    <td>
                                        <?php
                                        foreach ($appd['degree'] as $a => $b) { ?>
                                    <?=   ucfirst($b['qualification'])." ".ucfirst($b['programme'])." (". $b['cgpa'].")"."<br><br>"; ?>
                                           
                                      <?php  }

                                        ?>
                                    </td>
                                    
                                    <td>
                                        <?php
                                        if (isset($appd['referee'])) {
                                            $i = 0;
                                            foreach ($appd['referee'] as $a => $b) { ?>
                                               <?= (++$i) . ' ' . $b . "<br>"; ?>
                                         <?php   }
                                        } ?>
                                    </td>
                                    <td>

                                    </td>
                                    </tr>
                                <?php } ?>
                            </tbody>
    <?php
                        }
                    }
                }
            }
        }
    }

    ?>
</table>




     </div>
    </div>

</body>

</html>