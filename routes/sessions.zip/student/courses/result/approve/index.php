<?php 


echo http_response_code(403)


?>